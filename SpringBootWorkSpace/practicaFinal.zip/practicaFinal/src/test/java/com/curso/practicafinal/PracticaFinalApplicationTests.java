package com.curso.practicafinal;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PracticaFinalApplicationTests {

	@Test
	void contextLoads() {
	}

}
